import sys


collect_ignore = ['setup.py', 'docs']
