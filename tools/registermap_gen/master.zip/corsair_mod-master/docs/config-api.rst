.. _config-api:

=============
Configuration
=============

.. automodule:: corsair.config
   :members:
   :undoc-members:
