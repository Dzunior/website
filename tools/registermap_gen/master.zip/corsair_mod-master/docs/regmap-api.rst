.. _regmap-api:

============
Register map
============

EnumValue
=========
.. autoclass:: corsair.EnumValue
   :members:
   :undoc-members:

BitField
========
.. autoclass:: corsair.BitField
   :members:
   :undoc-members:

Register
========
.. autoclass:: corsair.Register
   :members:
   :undoc-members:

RegisterMap
===========
.. autoclass:: corsair.RegisterMap
   :members:
   :undoc-members:
